import 'dart:convert';
import 'package:hotel/config/api_config.dart' as ApiConfig;
import 'package:hotel/config/api_config.dart';
import 'package:http/http.dart' as http;

class BookingService {
  final url = Uri.parse('${ApiConfig.baseUrl}/api/v1/bookings');
  // Ganti sesuai backend kamu

  Future<void> submitBooking({
    required DateTime checkInDate,
    required DateTime checkOutDate,
    required String guestFullName,
    required String guestEmail,
    required int numOfAdults,
    required int numOfChildren,
    required int totalNumOfGuest,
    required String bookingConfirmationCode,
    required int roomId,
  }) async {
    try {
      final response = await http.post(
        Uri.parse(baseUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "checkInDate": checkInDate.toIso8601String(),
          "checkOutDate": checkOutDate.toIso8601String(),
          "guestFullName": guestFullName,
          "guestEmail": guestEmail,
          "numOfAdults": numOfAdults,
          "numOfChildren": numOfChildren,
          "totalNumOfGuest": totalNumOfGuest,
          "bookingConfirmationCode": bookingConfirmationCode,
          "roomId": roomId,
        }),
      );

      if (response.statusCode != 200 && response.statusCode != 201) {
        throw Exception('Booking failed: ${response.body}');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }
}
